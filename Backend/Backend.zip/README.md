
## Project setup
```
npm install
```

### Run
```
node server.js
```
