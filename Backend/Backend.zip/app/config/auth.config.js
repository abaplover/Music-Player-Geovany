module.exports = {
  secret: "music-secret-key"
};
