module.exports = {
  HOST: "localhost",
  USER: "informa3_music_player",
  PASSWORD: "UB$4Xss{I+N+",
  DB: "informa3_musicplayer",
  dialect: "mysql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
